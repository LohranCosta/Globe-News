<?php
$host = "localhost";
$usuario= "root";
$senha = "";
$bd = "globe";

$mysqli = new mysqli($host, $usuario, $senha, $bd);

?>