<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "globe";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);